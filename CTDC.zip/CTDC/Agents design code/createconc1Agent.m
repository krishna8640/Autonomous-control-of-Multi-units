function agent2 = createconc1Agent(obsInfo,actInfo,Ts)
% Helper function for creating a DDPG agent.

% Define observation path
obsPath = [
    sequenceInputLayer(prod(obsInfo.Dimension),Name="obsIn")
    fullyConnectedLayer(500)
    reluLayer
    fullyConnectedLayer(300,Name="obsOut")
    ];

% Define action path
actPath = [
    sequenceInputLayer(prod(actInfo.Dimension),Name="actIn")
    fullyConnectedLayer(500,Name="actOut")
    ];

% Define common path
commonPath = [
    concatenationLayer(1,2,Name="cat")
    reluLayer
    lstmLayer(128);
    fullyConnectedLayer(1)
    ];

% Add layers to layerGraph object
criticNet = layerGraph;
criticNet = addLayers(criticNet,obsPath);
criticNet = addLayers(criticNet,actPath);
criticNet = addLayers(criticNet,commonPath);

% Connect paths
criticNet = connectLayers(criticNet,"obsOut","cat/in1");
criticNet = connectLayers(criticNet,"actOut","cat/in2");
criticNet1 = dlnetwork(criticNet);
criticNet2 = dlnetwork(criticNet);
critic1 = rlQValueFunction(criticNet1,obsInfo,actInfo);
critic2 = rlQValueFunction(criticNet2,obsInfo,actInfo);
actorNet = [
    sequenceInputLayer(prod(obsInfo.Dimension))
    fullyConnectedLayer(500)
    lstmLayer(128)
    reluLayer
    fullyConnectedLayer(300,"Name","ActorFC2")
    reluLayer
    fullyConnectedLayer(prod(actInfo.Dimension))                       
    tanhLayer
    ];
actorNet = dlnetwork(actorNet);
actor  = rlContinuousDeterministicActor(actorNet,obsInfo,actInfo);
criticOptions = rlOptimizerOptions( ...
    Optimizer="adam", ...
    LearnRate=1e-3,... 
    GradientThreshold=1, ...
    L2RegularizationFactor=2e-4);
actorOptions = rlOptimizerOptions( ...
    Optimizer="adam", ...
    LearnRate=1e-3,...
    GradientThreshold=1, ...
    L2RegularizationFactor=1e-5);
agentOptions = rlTD3AgentOptions;
agentOptions.DiscountFactor = 0.99;
agentOptions.SequenceLength = 64;
agentOptions.TargetSmoothFactor = 5e-3;
agentOptions.TargetPolicySmoothModel.Variance = 0.2;
agentOptions.TargetPolicySmoothModel.LowerLimit = -0.5;
agentOptions.TargetPolicySmoothModel.UpperLimit = 0.5;
agentOptions.CriticOptimizerOptions = criticOptions;
agentOptions.ActorOptimizerOptions = actorOptions;
agent2 = rlTD3Agent(actor,[critic1 critic2],agentOptions);








