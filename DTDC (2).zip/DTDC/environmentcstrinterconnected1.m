mdl = "intercstrstablesim111";
open_system(mdl)
numObs = 13;
numAct = 1;
obsInfo1  = rlNumericSpec([numObs 1]);
actInfo1  = rlNumericSpec([numAct 1]);
obsInfo2  = rlNumericSpec([numObs 1]);
actInfo2  = rlNumericSpec([numAct 1]);
obsInfo3 =  rlNumericSpec([numObs 1]);
actInfo3  = rlNumericSpec([numAct 1]);
obsInfo4  = rlNumericSpec([numObs 1]);
actInfo4  = rlNumericSpec([numAct 1]);
obsInfo   = {obsInfo1,obsInfo2,obsInfo3,obsInfo4};
actInfo = {actInfo1,actInfo2,actInfo3,actInfo4};
agentBlks = mdl + ["/RL Agent1","/RL Agent2","/RL Agent3","/RL Agent4"];
env = rlSimulinkEnv(mdl, agentBlks, obsInfo , actInfo );
rng(100)
Ts = 0.1;
agent1 = conc1Agent123(numObs,numAct,obsInfo1,actInfo1,Ts);
agent2 = conc1Agent123(numObs,numAct,obsInfo2,actInfo2,Ts);
agent3 = conc1Agent123(numObs,numAct,obsInfo3,actInfo3,Ts);
agent4 = conc1Agent123(numObs,numAct,obsInfo4,actInfo4,Ts);
Tf = 25; % simulation time
maxepisodes = 5000;
maxsteps = ceil(Tf/Ts);
trainingOpts = rlMultiAgentTrainingOptions(...
    AgentGroups ={[1 2 3 4]},...
    LearningStrategy=["decentralized"],...
    MaxEpisodes=maxepisodes,...
    MaxStepsPerEpisode=maxsteps,...
    Verbose=false,...
    Plots="training-progress",...
    StopTrainingCriteria="AverageReward",...
    StopTrainingValue=[0,0,0,0]);
doTraining = true;
if doTraining    
    % Train the agent.
    trainingStats = train([agent1,agent2,agent3,agent4],env,trainingOpts);
else
    % Load pretrained agents for the example.
    load("rlPFCAgents.mat")       
end