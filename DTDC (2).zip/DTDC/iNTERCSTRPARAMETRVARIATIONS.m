syms x1 x2 x3 x4 u1 u2 u3 u4;
f0 = 5.4998;f1 = 39.996;f3 = 33;fr= 39.998;v1 =1.0;v2=3.0;R= 8.314;T0= 330;T03 = 330;Ca03 = 2.2;
Dh1 = -5*(10)^4;Dh2 = -5.2*(10)^4;Dh3 = -5.4*(10)^4;k10 = 3*(10)^6;k20 = 3*(10)^5;k30 = 3*(10)^5;
E1= 7.0*(10)^4;E2 = 10.542*(10)^4;E3 =10.542*(10)^4;rho =1000;cp =0.231;Ca0= 4.4;Q1 =0;Q2=0;
p1 = (f0/v1)*(T0-x1)+(fr/v1)*(x3-x1)+((-Dh1/(rho*cp))*k10*exp(-E1/(R*x1))+(-Dh2/(rho*cp))*k20*exp(-E2/(R*x1))+(-Dh3/(rho*cp))*k30*exp(-E3/(R*x1)))*(x2)+(u1/(rho*cp*v1));
p2= (f0/v1)*(u2-x2)+(fr/v1)*(x4-x2)-(k10*exp(-E1/(R*x1))+k20*exp(-E2/(R*x1))+k30*exp(-E3/(R*x1)))*x2;
p3= (f1/v2)*(x1-x3)+(f3/v2)*(T03-x3)+((-Dh1/(rho*cp))*k10*exp(-E1/(R*x3))+(-Dh2/(rho*cp))*k20*exp(-E2/(R*x3))+(-Dh3/(rho*cp))*k30*exp(-E3/(R*x3)))*(x4)+(u3/(rho*cp*v2));
p4= (f1/v2)*(x2-x4)+(f3/v2)*(u4-x4)-(k10*exp(-E1/(R*x3))+k20*exp(-E2/(R*x3))+k30*exp(-E3/(R*x3)))*x4;
F = [p1,p2]
m1 = [x1 x2]
P1= [300.3878 2.4981];
J1=jacobian(F,m1);
A1=subs(J1,m1,P1);
A1=double(A1)
eig(A1)
m2 =[x3 x4]
P2= [300.3496 2.2840];
J2=jacobian(F,m2);
A12=subs(J2,m2,P2);
A12=double(A12)
eig(A12)
n1 = [u1 u2];
W1 = [0 Ca0];
I1 = jacobian(F,n1);
B1= subs(I1,n1,W1);
B1=double(B1)
%second system
F2 = [p3,p4]
J3=jacobian(F2,m2);
A2=subs(J3,m2,P2);
A2=double(A2)
eig(A2)
J4=jacobian(F2,m1);
A21=subs(J4,m1,P1);
A21=double(A21)
eig(A21)
n2 = [u3 u4];
W2 = [0 Ca03];
I2 = jacobian(F2,n2);
B2= subs(I2,n2,W2);
B2=double(B2)
