plot(out.time1,out.u1,out.time1,out.u3,'LineWidth',2);
xlabel('Time,t(s)');
%ylabel(['Feed Inlet Concentration Reactor 1&2(Kmol/m3).'])
ylabel(['Rate of Heat Input to Reactor 1&2(KJ/hr).'])
grid on
%lgd =legend('Normalized Feed Inlet Concentration Reactor1.','Normalized Feed Inlet Concentration Reactor2');
lgd =legend('Normalized Rate of Heat Input to Reactor1.','Normalized Rate of Heat Input to Reactor2');
%char(176) 'C