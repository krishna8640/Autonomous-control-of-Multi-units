mdl = "xxxxx";
open_system(mdl)
numObs = 16;
numAct = 1;
obsInfo1  = rlNumericSpec([numObs 1]);
actInfo1  = rlNumericSpec([numAct 1]);
obsInfo2  = rlNumericSpec([numObs 1]);
actInfo2  = rlNumericSpec([numAct 1]);
obsInfo3 =  rlNumericSpec([numObs 1]);
actInfo3  = rlNumericSpec([numAct 1]);
obsInfo4  = rlNumericSpec([numObs 1]);
actInfo4  = rlNumericSpec([numAct 1]);
obsInfo   = {obsInfo1,obsInfo2,obsInfo3,obsInfo4};
actInfo = {actInfo1,actInfo2,actInfo3,actInfo4};
agentBlks = mdl + ["/RL Agent1","/RL Agent2","/RL Agent3","/RL Agent4"];
env = rlSimulinkEnv(mdl, agentBlks, obsInfo , actInfo );
%env.ResetFcn = @(in)localResetFcn(in);
rng(100)

Ts = 0.1;
agent1 = createconc1Agent(obsInfo1,actInfo1,Ts);
agent2 = createconc1Agent(obsInfo2,actInfo2,Ts);
agent3 = createconc1Agent(obsInfo3,actInfo3,Ts);
agent4 = createconc1Agent(obsInfo4,actInfo4,Ts);
Tf = 25; % simulation time
maxepisodes = 25000;
maxsteps = ceil(Tf/Ts);
trainingOpts = rlMultiAgentTrainingOptions(...
    AgentGroups ={[1 2 3 4]},...
    LearningStrategy=("centralized"),...
    MaxEpisodes=maxepisodes,...
    MaxStepsPerEpisode=maxsteps,...
    Verbose=false,...
    Plots="training-progress",...
    StopTrainingCriteria="AverageReward",...
    StopTrainingValue=[2500,2500,2500,2500]);
doTraining = true;
if doTraining    
    % Train the agent.
    trainingStats = train([agent1,agent2,agent3,agent4],env,trainingOpts);
else
    % Load pretrained agents for the example.
    load("rlPFCAgents.mat")       
end
function in = localResetFcn(in)
blk = sprintf('xxxxx/Desired1');
h1 = (30).*rand;
in = setBlockParameter(in,blk,'Value',num2str(h1));
% randomize initial height
blk = sprintf('xxxxx/Desired2');
h2 = (20).*rand;
in = setBlockParameter(in,blk,'Value',num2str(h2));
% randomize initial height
h3 = (30).*rand;
blk = sprintf('xxxxx/Desired3');
in = setBlockParameter(in,blk,'Value',num2str(h3));
% randomize initial height
h4 = (40).*rand;
blk = sprintf('xxxxx/Desired4');
in = setBlockParameter(in,blk,'Value',num2str(h4));
end
