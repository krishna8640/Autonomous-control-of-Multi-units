mdl = "intercstrstablesim11";
open_system(mdl)
numObs =8;
numAct = 1;
obsInfo  = rlNumericSpec([numObs 1]);
actInfo  = rlNumericSpec([numAct 1]);
agentBlks = mdl + ["/RL Agent1"];
env = rlSimulinkEnv(mdl, agentBlks, obsInfo , actInfo );
rng(100)