open_system("LevelCheckBlock")
generateRewardFunction("LevelCheckBlock/Level Check")
type myBlockRewardFcn.m